﻿namespace Domain.DTOs.AuthenticationDtos;

public record ErrorResponseDto(string Code, string Description);
