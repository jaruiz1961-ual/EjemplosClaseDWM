﻿namespace Domain.DTOs.CourseDTOs;

public record CourseCreateDto(string Title, int Credits);

