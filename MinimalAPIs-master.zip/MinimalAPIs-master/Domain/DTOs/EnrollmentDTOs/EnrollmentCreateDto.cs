﻿namespace Domain.DTOs.EnrollmentDTOs;

public record EnrollmentCreateDto(
    int CourseId,
    int StudentId
    );
