﻿namespace Domain.DTOs.CourseDTOs;

public record CourseDto(int Id, string Title, int Credits);

