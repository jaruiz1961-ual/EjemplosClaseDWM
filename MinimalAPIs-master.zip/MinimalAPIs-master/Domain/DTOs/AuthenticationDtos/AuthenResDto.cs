﻿namespace Domain.DTOs.AuthenticationDtos;

public record AuthenResDto(string UserId, string Token);
