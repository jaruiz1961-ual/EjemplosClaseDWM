﻿namespace Domain.DTOs.EnrollmentDTOs;

public record EnrollmentDto(
    int Id,
    int CourseId,
    int StudentId
    );
